﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// Calc2.rc에서 사용되고 있습니다.
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CALC2_DIALOG                102
#define IDR_MAINFRAME                   128
#define Btn_Number0                     1000
#define Btn_Number1                     1001
#define Btn_Number2                     1002
#define Btn_Number3                     1003
#define Btn_Number4                     1004
#define Btn_Number5                     1005
#define Btn_Number6                     1006
#define Btn_Number7                     1007
#define Btn_Number8                     1008
#define Btn_Number9                     1009
#define Print_History                   1010
#define Print_Result                    1011
#define Btn_PLUS                        1012
#define Btn_MINUS                       1013
#define Btn_Result                      1014
#define Btn_Clear                       1015
#define Btn_BackSpace                   1016
#define IDC_BUTTON1                     1017
#define Btn_Sign                        1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
